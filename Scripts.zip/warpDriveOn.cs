﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class warpDriveOn : MonoBehaviour
{   
    // initialize the particle system
    public ParticleSystem warpDrive;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ToggleWarpDrive(Collider plyr){
        if (plyr.tag == "Player" && Input.GetKeyDown(KeyCode.E)){
            if(warpDrive.isPlaying){
                warpDrive.Stop();
            }
            else {
                warpDrive.Play();
            }
        }
    }
}
